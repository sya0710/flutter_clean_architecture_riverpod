import 'package:freezed_annotation/freezed_annotation.dart';

part 'app_state.freezed.dart';

@freezed
abstract class AppState with _$AppState {
  const factory AppState({
    String? appTitle,
    bool? isUnauthorized,
    bool? isNoNetwork,
    bool? isTimeOut,
  }) = _AppState;
}
