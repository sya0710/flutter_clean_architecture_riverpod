enum AuthAction { none, login }
